class FakeUsersRepository {
  async findByEmail() {}

  async findById() {}

  async create() {}
}

module.exports = FakeUsersRepository;
